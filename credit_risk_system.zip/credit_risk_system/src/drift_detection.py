"""
Temporal Drift Detection
------------------------
Monitors feature distributions (payment_delay, transaction_count,
credit_inquiry) over time per customer and flags significant drift between
a baseline window and the most recent 30-day rolling window.

Per the project constraints, only NumPy/Pandas may be used (no SciPy), so
the two-sample Kolmogorov-Smirnov statistic is implemented manually using
empirical CDFs. Drift is flagged when KS statistic > DRIFT_KS_THRESHOLD
(default 0.3) or when the mean shifts by more than DRIFT_MEAN_PCT_THRESHOLD
(default 15%), matching the spec's ">15% change in mean" and "KS > 0.3"
criteria.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import numpy as np
import pandas as pd

DRIFT_KS_THRESHOLD = 0.3
DRIFT_MEAN_PCT_THRESHOLD = 0.15
ROLLING_WINDOW_DAYS = 30
DRIFT_FEATURES = ["payment_delay", "transaction_count", "credit_inquiry"]


@dataclass
class DriftResult:
    feature: str
    ks_statistic: float
    baseline_mean: float
    current_mean: float
    mean_pct_change: float
    drifted: bool


def _ks_statistic(sample_a: np.ndarray, sample_b: np.ndarray) -> float:
    """Manual two-sample KS statistic (max distance between empirical CDFs)."""
    if len(sample_a) == 0 or len(sample_b) == 0:
        return 0.0
    all_values = np.sort(np.concatenate([sample_a, sample_b]))
    cdf_a = np.searchsorted(np.sort(sample_a), all_values, side="right") / len(sample_a)
    cdf_b = np.searchsorted(np.sort(sample_b), all_values, side="right") / len(sample_b)
    return float(np.max(np.abs(cdf_a - cdf_b)))


def detect_drift(
    customer_history: pd.DataFrame,
    as_of: pd.Timestamp,
    baseline_history: pd.DataFrame = None,
) -> List[DriftResult]:
    """
    Compare the customer's rolling 30-day window (ending at `as_of`) against
    a baseline distribution (earlier history, or the same customer's first
    observed window if no external baseline is supplied).
    """
    results: List[DriftResult] = []
    window_start = as_of - pd.Timedelta(days=ROLLING_WINDOW_DAYS)
    current_window = customer_history[
        (customer_history["timestamp"] > window_start) & (customer_history["timestamp"] <= as_of)
    ]

    if baseline_history is None or baseline_history.empty:
        baseline_window = customer_history[customer_history["timestamp"] <= window_start]
        if baseline_window.empty:
            # Not enough history to compare yet -- no drift can be assessed.
            for feature in DRIFT_FEATURES:
                results.append(DriftResult(feature, 0.0, 0.0, 0.0, 0.0, False))
            return results
    else:
        baseline_window = baseline_history

    for feature in DRIFT_FEATURES:
        if feature not in customer_history.columns:
            continue
        base_vals = pd.to_numeric(baseline_window[feature], errors="coerce").dropna().to_numpy()
        curr_vals = pd.to_numeric(current_window[feature], errors="coerce").dropna().to_numpy()

        if len(base_vals) == 0 or len(curr_vals) == 0:
            results.append(DriftResult(feature, 0.0, 0.0, 0.0, 0.0, False))
            continue

        ks_stat = _ks_statistic(base_vals, curr_vals)
        base_mean = float(np.mean(base_vals))
        curr_mean = float(np.mean(curr_vals))
        mean_pct_change = (
            abs(curr_mean - base_mean) / abs(base_mean) if base_mean != 0 else (1.0 if curr_mean != 0 else 0.0)
        )

        drifted = ks_stat > DRIFT_KS_THRESHOLD or mean_pct_change > DRIFT_MEAN_PCT_THRESHOLD
        results.append(
            DriftResult(
                feature=feature,
                ks_statistic=round(ks_stat, 4),
                baseline_mean=round(base_mean, 4),
                current_mean=round(curr_mean, 4),
                mean_pct_change=round(mean_pct_change, 4),
                drifted=drifted,
            )
        )

    return results


def any_drift(results: List[DriftResult]) -> bool:
    return any(r.drifted for r in results)


def drift_results_to_dict(results: List[DriftResult]) -> Dict:
    return {r.feature: r.__dict__ for r in results}
