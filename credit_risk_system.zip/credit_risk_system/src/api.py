"""
FastAPI server.

Run with:
    uvicorn src.api:app --reload

Endpoints:
    POST /events -> ingest a single event as JSON.
        200 on success (processed or duplicate)
        409 if the event_id was already processed (duplicate replay) --
            NOTE: duplicates are still handled idempotently and return the
            existing decision in the body; 409 signals "no new state change."
        400 if the event is malformed (missing required fields)
"""

from __future__ import annotations

import pandas as pd
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Optional

from .event_processor import EventProcessor, MalformedEventError

app = FastAPI(title="Real-Time Credit Risk Reassessment API")


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    # The spec requires 400 (not FastAPI's default 422) for malformed events.
    return JSONResponse(status_code=400, content={"error": "Malformed event", "details": exc.errors()})

_processor: Optional[EventProcessor] = None


def get_processor() -> EventProcessor:
    global _processor
    if _processor is None:
        _processor = EventProcessor()
    return _processor


class EventIn(BaseModel):
    event_id: str
    timestamp: str
    customer_id: Optional[str] = None
    account_id: Optional[str] = None
    payment_delay: Optional[float] = None
    transaction_count: Optional[float] = None
    credit_inquiry: Optional[float] = None
    source: Optional[str] = None
    is_default: Optional[int] = None


@app.post("/events")
def ingest_event(event: EventIn):
    processor = get_processor()
    df = pd.DataFrame([event.model_dump()])
    try:
        results = processor.process_events(df)
    except MalformedEventError as e:
        return JSONResponse(status_code=400, content={"error": str(e)})
    except RuntimeError as e:
        return JSONResponse(status_code=400, content={"error": str(e)})

    if not results:
        return JSONResponse(status_code=400, content={"error": "Event could not be resolved"})

    result = results[0]
    if result["status"] == "duplicate":
        return JSONResponse(status_code=409, content=result)
    return JSONResponse(status_code=200, content=result)


@app.get("/health")
def health():
    return {"status": "ok"}
