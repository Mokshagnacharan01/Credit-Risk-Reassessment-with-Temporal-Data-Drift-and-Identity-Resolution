"""
CLI entry point.

Usage:
    python -m src.cli bootstrap --historical data/samples/historical_train.csv
    python -m src.cli ingest --file data/samples/edge_case_1_identity_conflict.csv
"""

from __future__ import annotations

import argparse
import json
import sys

import pandas as pd

from .event_processor import EventProcessor, MalformedEventError


def cmd_bootstrap(args):
    hist_df = pd.read_csv(args.historical)
    processor = EventProcessor.__new__(EventProcessor)  # avoid requiring a trained model to init
    processor.model_version = "v1"
    processor.model = None
    processor.train_initial_model(hist_df)
    print(f"Model trained and saved as version 'v1' using {len(hist_df)} historical rows.")


def cmd_ingest(args):
    df = pd.read_csv(args.file)
    processor = EventProcessor()
    try:
        results = processor.process_events(df)
    except MalformedEventError as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)

    for r in results:
        print(json.dumps(r, default=str))

    n_processed = sum(1 for r in results if r["status"] == "processed")
    n_dup = sum(1 for r in results if r["status"] == "duplicate")
    print(f"\nSummary: {n_processed} processed, {n_dup} duplicate/idempotent, {len(results)} total.", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(description="Real-Time Credit Risk Reassessment CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_boot = sub.add_parser("bootstrap", help="Train the initial risk model from historical data")
    p_boot.add_argument("--historical", required=True, help="Path to historical CSV with is_default labels")
    p_boot.set_defaults(func=cmd_bootstrap)

    p_ingest = sub.add_parser("ingest", help="Ingest a CSV file of new events")
    p_ingest.add_argument("--file", required=True, help="Path to CSV file of events")
    p_ingest.set_defaults(func=cmd_ingest)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
