"""
Event Processor
----------------
Orchestrates the end-to-end pipeline:
  1. Identity resolution across incoming events.
  2. Idempotent replay handling (skip already-processed event_ids).
  3. Temporal drift detection per merged customer.
  4. Risk reassessment via the versioned logistic regression model.
  5. Audit trail generation for every decision (including skipped ones).

Determinism: events are always processed in (timestamp, event_id) order
regardless of the order they arrive in the input file/request, so replaying
a shuffled version of the same event set produces identical final state.
"""

from __future__ import annotations

import os
from collections import Counter
from typing import Dict, List

import pandas as pd

from . import risk_model
from .audit import write_audit
from .drift_detection import any_drift, detect_drift, drift_results_to_dict
from .event_log import EventLog
from .identity_resolution import resolve_identities

REQUIRED_COLUMNS = [
    "event_id",
    "timestamp",
    "customer_id",
    "account_id",
    "payment_delay",
    "transaction_count",
    "credit_inquiry",
    "source",
    "is_default",
]

CURRENT_MODEL_VERSION = "v1"


class MalformedEventError(ValueError):
    pass


def validate_events(df: pd.DataFrame) -> None:
    missing_cols = [c for c in ["event_id", "timestamp"] if c not in df.columns]
    if missing_cols:
        raise MalformedEventError(f"Missing required columns: {missing_cols}")
    if df["event_id"].isna().any():
        raise MalformedEventError("event_id is required for every event")
    if df["timestamp"].isna().any():
        raise MalformedEventError("timestamp is required for every event")


def _resolve_is_default_conflict(cluster_events: pd.DataFrame) -> Dict:
    """
    Resolve conflicting is_default labels within a merged customer's event
    history via majority vote; ties are broken by the most recent timestamp.
    Returns a dict describing the conflict (empty if no conflict existed).
    """
    if "is_default" not in cluster_events.columns:
        return {}
    labels = cluster_events["is_default"].dropna()
    if labels.empty:
        return {}
    unique_vals = labels.unique()
    if len(unique_vals) <= 1:
        return {}

    counts = Counter(labels.tolist())
    top_count = max(counts.values())
    tied = [v for v, c in counts.items() if c == top_count]
    if len(tied) == 1:
        resolved = tied[0]
        method = "majority_vote"
    else:
        # tie-break: most recent timestamp among tied labels
        tied_rows = cluster_events[cluster_events["is_default"].isin(tied)]
        resolved = tied_rows.sort_values("timestamp").iloc[-1]["is_default"]
        method = "majority_vote_tie_broken_by_most_recent_timestamp"

    return {
        "conflict": True,
        "observed_values": {str(k): v for k, v in counts.items()},
        "resolved_value": resolved,
        "resolution_method": method,
    }


class EventProcessor:
    def __init__(self, model=None, model_version: str = CURRENT_MODEL_VERSION):
        self.model_version = model_version
        self.model = model if model is not None else self._load_or_bootstrap_model()
        self.risk_state = risk_model.RiskState.load()
        self.event_log = EventLog()
        # Full history of all events ever seen (for drift baselines), in memory
        # and persisted to disk so state survives across runs.
        self.history_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "audit_logs", "full_history.csv"
        )
        self.history = self._load_history()

    def _load_or_bootstrap_model(self):
        model_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models", f"model_{self.model_version}.pkl"
        )
        if os.path.exists(model_path):
            return risk_model.load_model(self.model_version)
        # No trained model yet -- caller must train explicitly via train_initial_model()
        return None

    def _load_history(self) -> pd.DataFrame:
        if os.path.exists(self.history_path):
            return pd.read_csv(self.history_path, parse_dates=["timestamp"])
        return pd.DataFrame(columns=REQUIRED_COLUMNS + ["merged_customer_id"])

    def _save_history(self) -> None:
        os.makedirs(os.path.dirname(self.history_path), exist_ok=True)
        self.history.to_csv(self.history_path, index=False)

    def train_initial_model(self, historical_df: pd.DataFrame) -> None:
        self.model = risk_model.train_model(historical_df, self.model_version)

    def process_events(self, new_events: pd.DataFrame) -> List[Dict]:
        """
        Process a batch of new events. Returns a list of per-event result
        dicts: {event_id, status, merged_customer_id, score, audit_file}
        status in {"processed", "duplicate", "error"}.
        """
        validate_events(new_events)
        df = new_events.copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"])

        # Deterministic processing order: chronological, then event_id.
        df = df.sort_values(["timestamp", "event_id"], kind="stable").reset_index(drop=True)

        # Resolve identities jointly against existing history + new batch so
        # that new events can merge into previously-seen customers.
        combined = pd.concat([self.history, df], ignore_index=True, sort=False)
        combined = combined.drop_duplicates(subset=["event_id"], keep="last")
        combined_resolved = resolve_identities(combined)

        results = []
        new_rows_buffer: List[Dict] = []

        # Pre-group existing history by merged_customer_id for O(1) lookups
        # instead of re-filtering the (growing) full history on every event.
        event_id_to_row = {
            str(r["event_id"]): r for r in combined_resolved.to_dict("records")
        }
        cluster_buffers: Dict[str, List[Dict]] = {}
        if not self.history.empty:
            for cid, group in self.history.groupby("merged_customer_id"):
                cluster_buffers[cid] = group.to_dict("records")

        for _, event in df.iterrows():
            event_id = str(event["event_id"])
            row = event_id_to_row.get(event_id)
            if row is None:
                continue
            merged_customer_id = row["merged_customer_id"]
            resolution_reason = row["resolution_reason"]

            if self.event_log.is_processed(event_id):
                audit_file = write_audit(
                    event_ids=[event_id],
                    merged_customer_id=merged_customer_id,
                    drift_detected=False,
                    drift_details={},
                    model_version=self.model_version,
                    score=self.risk_state.get(merged_customer_id),
                    reasoning=["Event already processed; replay is idempotent, no state change."],
                    duplicate=True,
                    timestamp=str(event["timestamp"]),
                )
                results.append(
                    {
                        "event_id": event_id,
                        "status": "duplicate",
                        "merged_customer_id": merged_customer_id,
                        "score": self.risk_state.get(merged_customer_id),
                        "audit_file": audit_file,
                    }
                )
                continue

            # Append this event to the in-memory cluster buffer (avoids
            # per-event pandas concat, which is O(n) and makes the whole
            # loop O(n^2)).
            new_row = event.to_dict()
            new_row["merged_customer_id"] = merged_customer_id
            cluster_buffers.setdefault(merged_customer_id, []).append(new_row)
            new_rows_buffer.append(new_row)

            cluster_events = cluster_buffers[merged_customer_id]
            cluster_history = pd.DataFrame(cluster_events)
            cluster_history["timestamp"] = pd.to_datetime(cluster_history["timestamp"])

            # Late event check: is this earlier than the customer's latest
            # previously-known timestamp?
            prior_events = cluster_history[cluster_history["event_id"] != event["event_id"]]
            late_event = False
            if not prior_events.empty:
                late_event = event["timestamp"] < prior_events["timestamp"].max()

            # Drift detection over the customer's full (chronologically
            # sorted) history, as of this event's timestamp.
            cluster_sorted = cluster_history.sort_values("timestamp")
            drift_results = detect_drift(cluster_sorted, as_of=event["timestamp"])
            drift_flag = any_drift(drift_results)

            # Conflicting is_default resolution.
            conflict_info = _resolve_is_default_conflict(cluster_history)

            # Risk reassessment: any new event is new evidence -> recompute.
            feature_row = {
                "payment_delay": event.get("payment_delay"),
                "transaction_count": event.get("transaction_count"),
                "credit_inquiry": event.get("credit_inquiry"),
            }
            if self.model is None:
                raise RuntimeError("Model has not been trained. Call train_initial_model() first.")
            score = risk_model.score_features(self.model, feature_row)
            self.risk_state.update(
                merged_customer_id, score, self.model_version, event_id, str(event["timestamp"])
            )

            reasoning = [f"Identity resolution: {resolution_reason}."]
            reasoning.append(
                "New event ingested -> risk score recomputed with model "
                f"{self.model_version}."
            )
            if drift_flag:
                reasoning.append("Temporal drift detected in one or more features; re-evaluation triggered.")
            if late_event:
                reasoning.append("Event timestamp is earlier than previously seen events for this customer (late event); state updated retroactively.")
            if conflict_info:
                reasoning.append(
                    f"Conflicting is_default labels resolved via {conflict_info['resolution_method']}."
                )

            audit_file = write_audit(
                event_ids=[event_id],
                merged_customer_id=merged_customer_id,
                drift_detected=drift_flag,
                drift_details=drift_results_to_dict(drift_results),
                model_version=self.model_version,
                score=score,
                reasoning=reasoning,
                late_event=late_event,
                duplicate=False,
                is_default_conflict=conflict_info or None,
                timestamp=str(event["timestamp"]),
            )

            self.event_log.mark_processed(event_id, merged_customer_id, audit_file)
            results.append(
                {
                    "event_id": event_id,
                    "status": "processed",
                    "merged_customer_id": merged_customer_id,
                    "score": score,
                    "audit_file": audit_file,
                }
            )

        if new_rows_buffer:
            self.history = pd.concat(
                [self.history, pd.DataFrame(new_rows_buffer)], ignore_index=True, sort=False
            )

        self.event_log.save()
        self.risk_state.save()
        self._save_history()
        return results
