"""
Event Log
---------
Tracks which event_ids have already been processed so that replaying the
same event never triggers a duplicate risk update (idempotency).
Persisted locally as JSON -- no external database, per constraints.
"""

from __future__ import annotations

import json
import os
from typing import Dict, Optional, Set

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "audit_logs")
LOG_PATH = os.path.join(LOG_DIR, "event_log.json")


class EventLog:
    def __init__(self):
        self.processed: Dict[str, Dict] = {}
        self._load()

    def _load(self) -> None:
        if os.path.exists(LOG_PATH):
            with open(LOG_PATH, "r") as f:
                self.processed = json.load(f)

    def save(self) -> None:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(LOG_PATH, "w") as f:
            json.dump(self.processed, f, indent=2, default=str)

    def is_processed(self, event_id: str) -> bool:
        return str(event_id) in self.processed

    def mark_processed(self, event_id: str, merged_customer_id: str, audit_file: str) -> None:
        self.processed[str(event_id)] = {
            "merged_customer_id": merged_customer_id,
            "audit_file": audit_file,
        }

    def get(self, event_id: str) -> Optional[Dict]:
        return self.processed.get(str(event_id))

    def reset(self) -> None:
        self.processed = {}
        if os.path.exists(LOG_PATH):
            os.remove(LOG_PATH)
