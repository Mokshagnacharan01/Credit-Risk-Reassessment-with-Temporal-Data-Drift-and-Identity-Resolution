"""
Audit Trail Generation
-----------------------
Writes a JSON audit file for every risk decision (or skipped/duplicate
decision), capturing input events, identity resolution steps, drift
detection results, and the final decision + reasoning -- so every score is
fully explainable and traceable after the fact.
"""

from __future__ import annotations

import json
import os
from typing import Dict, List

AUDIT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "audit_logs")


def write_audit(
    event_ids: List[str],
    merged_customer_id: str,
    drift_detected: bool,
    drift_details: Dict,
    model_version: str,
    score,
    reasoning: List[str],
    late_event: bool = False,
    duplicate: bool = False,
    is_default_conflict: Dict = None,
    timestamp: str = "",
) -> str:
    os.makedirs(AUDIT_DIR, exist_ok=True)
    safe_customer = str(merged_customer_id).replace("/", "_")
    safe_ts = str(timestamp).replace(":", "-").replace(" ", "_")
    filename = f"{safe_customer}_{safe_ts}_{'-'.join(map(str, event_ids))}.json"
    path = os.path.join(AUDIT_DIR, filename)

    record = {
        "event_ids": event_ids,
        "merged_customer_id": merged_customer_id,
        "timestamp": timestamp,
        "duplicate_replay": duplicate,
        "late_event": late_event,
        "drift_detected": drift_detected,
        "drift_details": drift_details,
        "model_version": model_version,
        "score": score,
        "is_default_conflict": is_default_conflict,
        "reasoning": reasoning,
    }
    with open(path, "w") as f:
        json.dump(record, f, indent=2, default=str)
    return path
