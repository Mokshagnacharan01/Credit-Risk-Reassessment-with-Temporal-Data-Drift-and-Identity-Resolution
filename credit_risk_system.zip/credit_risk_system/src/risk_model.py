"""
Stateful Risk Reassessment
--------------------------
Trains a lightweight Logistic Regression model (scikit-learn, the only ML
library the constraints permit) on historical labeled events, and scores
customers' current feature state to produce a risk score in [0, 1].

Model versioning: every time the model is (re)trained, a version string is
generated (e.g. "v1", "v2", ...) and the fitted model is persisted to
`models/model_<version>.pkl`. The risk state store records which model
version produced each score, so audit trails are always reproducible.
"""

from __future__ import annotations

import json
import os
import pickle
from dataclasses import dataclass, field
from typing import Dict, Optional

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

FEATURES = ["payment_delay", "transaction_count", "credit_inquiry"]

MODELS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")
STATE_PATH = os.path.join(MODELS_DIR, "risk_state.json")


def train_model(historical_df: pd.DataFrame, version: str) -> LogisticRegression:
    """Train logistic regression on historical events with is_default labels."""
    df = historical_df.dropna(subset=FEATURES + ["is_default"]).copy()
    X = df[FEATURES].astype(float).to_numpy()
    y = df["is_default"].astype(int).to_numpy()

    model = LogisticRegression(max_iter=1000, random_state=42)
    if len(np.unique(y)) < 2:
        # Degenerate case: not enough class diversity to fit properly.
        # Fall back to a model that predicts the base rate deterministically.
        model = LogisticRegression(max_iter=1000, random_state=42)
        # Inject one synthetic contrasting sample so sklearn can fit.
        X = np.vstack([X, X[-1:] + 1e-3])
        y = np.append(y, 1 - y[-1])

    model.fit(X, y)
    os.makedirs(MODELS_DIR, exist_ok=True)
    with open(os.path.join(MODELS_DIR, f"model_{version}.pkl"), "wb") as f:
        pickle.dump(model, f)
    return model


def load_model(version: str) -> LogisticRegression:
    path = os.path.join(MODELS_DIR, f"model_{version}.pkl")
    with open(path, "rb") as f:
        return pickle.load(f)


def score_features(model: LogisticRegression, feature_row: Dict[str, float]) -> float:
    x = np.array([[float(feature_row.get(f, 0.0) or 0.0) for f in FEATURES]])
    proba = model.predict_proba(x)[0]
    # class 1 = default
    classes = list(model.classes_)
    if 1 in classes:
        return float(proba[classes.index(1)])
    return float(proba[0])


@dataclass
class RiskState:
    """Persisted per-customer state: current score, version, last event seen."""
    state: Dict[str, Dict] = field(default_factory=dict)

    @classmethod
    def load(cls) -> "RiskState":
        if os.path.exists(STATE_PATH):
            with open(STATE_PATH, "r") as f:
                return cls(state=json.load(f))
        return cls(state={})

    def save(self) -> None:
        os.makedirs(MODELS_DIR, exist_ok=True)
        with open(STATE_PATH, "w") as f:
            json.dump(self.state, f, indent=2, default=str)

    def get(self, customer_id: str) -> Optional[Dict]:
        return self.state.get(customer_id)

    def update(self, customer_id: str, score: float, model_version: str, last_event_id: str, last_timestamp: str) -> None:
        self.state[customer_id] = {
            "score": round(float(score), 6),
            "model_version": model_version,
            "last_event_id": last_event_id,
            "last_timestamp": str(last_timestamp),
        }
