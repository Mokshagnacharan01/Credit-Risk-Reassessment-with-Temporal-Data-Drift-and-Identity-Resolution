"""
Identity Resolution Engine
---------------------------
Merges events that belong to the same real-world customer even when
identifiers are missing, inconsistent, or conflicting across sources.

Strategy (deterministic, no ML/LLM):
1. account_id is treated as the strongest signal. Any two events that share
   a non-empty account_id are merged.
2. When account_id is missing/absent on one or both events, fall back to
   fuzzy matching on customer_id (string similarity via difflib, which is
   deterministic) combined with closeness of transaction_count (a proxy for
   "same behavioral history").
3. Union-Find (disjoint set) is used to transitively merge events into
   clusters. Clustering is order-independent: events are always sorted by
   event_id before processing, so replaying the same set of events in any
   order produces the same clusters.
4. Each cluster is assigned a canonical `merged_customer_id`, chosen
   deterministically as: the account_id of the cluster if any event has one,
   otherwise the lexicographically smallest non-null customer_id in the
   cluster. This guarantees the same cluster always resolves to the same id.
"""

from __future__ import annotations

import difflib
from dataclasses import dataclass
from typing import Dict, List, Optional

import pandas as pd

# Similarity thresholds (tunable, documented for auditability)
CUSTOMER_ID_SIMILARITY_THRESHOLD = 0.85
TRANSACTION_COUNT_MAX_DELTA = 2


@dataclass
class UnionFind:
    parent: Dict[int, int]

    @classmethod
    def create(cls, ids: List[int]) -> "UnionFind":
        return cls(parent={i: i for i in ids})

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, x: int, y: int) -> None:
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return
        # Deterministic tie-break: smaller root index wins as parent.
        if rx < ry:
            self.parent[ry] = rx
        else:
            self.parent[rx] = ry


def _is_missing(value) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and pd.isna(value):
        return True
    if isinstance(value, str) and value.strip() == "":
        return True
    if pd.isna(value):
        return True
    return False


def _customer_id_similar(a: Optional[str], b: Optional[str]) -> bool:
    if _is_missing(a) or _is_missing(b):
        return False
    if a == b:
        return True
    ratio = difflib.SequenceMatcher(None, str(a), str(b)).ratio()
    return ratio >= CUSTOMER_ID_SIMILARITY_THRESHOLD


def _transaction_counts_close(a, b) -> bool:
    if _is_missing(a) or _is_missing(b):
        return False
    try:
        return abs(float(a) - float(b)) <= TRANSACTION_COUNT_MAX_DELTA
    except (TypeError, ValueError):
        return False


def resolve_identities(events: pd.DataFrame) -> pd.DataFrame:
    """
    Given a DataFrame of raw events, return a copy with an added
    `merged_customer_id` column and a `resolution_reason` column explaining
    why each event landed in its cluster.
    """
    df = events.sort_values("event_id", kind="stable").reset_index(drop=True)
    n = len(df)
    uf = UnionFind.create(list(range(n)))

    account_ids = df["account_id"].tolist() if "account_id" in df.columns else [None] * n
    customer_ids = df["customer_id"].tolist() if "customer_id" in df.columns else [None] * n
    txn_counts = df["transaction_count"].tolist() if "transaction_count" in df.columns else [None] * n

    reasons = ["no_match_found"] * n

    # Pass 1: merge on account_id (strongest signal)
    account_id_to_first_index: Dict[str, int] = {}
    for i in range(n):
        acc = account_ids[i]
        if _is_missing(acc):
            continue
        key = str(acc)
        if key in account_id_to_first_index:
            uf.union(account_id_to_first_index[key], i)
            reasons[i] = "matched_account_id"
        else:
            account_id_to_first_index[key] = i

    # Pass 2: for events without a usable account_id, fuzzy match on
    # customer_id + transaction_count proximity, but ONLY against other
    # events that also lack an account_id. If the candidate peer *does*
    # have an account_id, account_id is the authoritative signal and a
    # mismatch (handled in Pass 1) means they are different customers --
    # fuzzy matching must not override that.
    for i in range(n):
        if not _is_missing(account_ids[i]):
            continue  # already resolved via account_id
        for j in range(i):
            if uf.find(i) == uf.find(j):
                continue
            if not _is_missing(account_ids[j]):
                continue  # j has an authoritative account_id; don't fuzzy-override
            if _customer_id_similar(customer_ids[i], customer_ids[j]) and _transaction_counts_close(
                txn_counts[i], txn_counts[j]
            ):
                uf.union(i, j)
                reasons[i] = "fuzzy_matched_customer_id_and_transaction_history"
                break

    # Assign canonical merged_customer_id per cluster, deterministically.
    clusters: Dict[int, List[int]] = {}
    for i in range(n):
        root = uf.find(i)
        clusters.setdefault(root, []).append(i)

    merged_ids = [None] * n
    for root, members in clusters.items():
        member_accounts = [account_ids[m] for m in members if not _is_missing(account_ids[m])]
        member_customers = sorted(
            {str(customer_ids[m]) for m in members if not _is_missing(customer_ids[m])}
        )
        if member_accounts:
            canonical = str(sorted({str(a) for a in member_accounts})[0])
        elif member_customers:
            canonical = member_customers[0]
        else:
            canonical = f"UNKNOWN_CUSTOMER_{root}"
        for m in members:
            merged_ids[m] = canonical

    df["merged_customer_id"] = merged_ids
    df["resolution_reason"] = reasons
    return df
