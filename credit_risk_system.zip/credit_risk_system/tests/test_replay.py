import pandas as pd


def _event(event_id, ts, cust="CUST1", acc="ACC1", pd_=2.0, tc=10, ci=0, default=0):
    return {
        "event_id": event_id,
        "timestamp": ts,
        "customer_id": cust,
        "account_id": acc,
        "payment_delay": pd_,
        "transaction_count": tc,
        "credit_inquiry": ci,
        "source": "payment",
        "is_default": default,
    }


def test_duplicate_event_id_is_marked_duplicate_and_does_not_change_score(processor):
    df = pd.DataFrame([_event("E1", "2025-06-01 09:00:00")])
    results1 = processor.process_events(df)
    assert results1[0]["status"] == "processed"
    score_after_first = processor.risk_state.get("ACC1")["score"]

    # Replay the exact same event.
    results2 = processor.process_events(df)
    assert results2[0]["status"] == "duplicate"
    score_after_replay = processor.risk_state.get("ACC1")["score"]

    assert score_after_first == score_after_replay


def test_replaying_a_batch_with_one_new_and_one_seen_event(processor):
    df1 = pd.DataFrame([_event("E1", "2025-06-01 09:00:00")])
    processor.process_events(df1)

    df2 = pd.DataFrame([
        _event("E1", "2025-06-01 09:00:00"),  # already seen
        _event("E2", "2025-06-01 10:00:00", pd_=3.0),  # new
    ])
    results = processor.process_events(df2)
    statuses = {r["event_id"]: r["status"] for r in results}
    assert statuses["E1"] == "duplicate"
    assert statuses["E2"] == "processed"


def test_replay_out_of_original_order_still_idempotent(processor):
    df = pd.DataFrame([
        _event("E1", "2025-06-01 09:00:00"),
        _event("E2", "2025-06-01 10:00:00"),
    ])
    processor.process_events(df)
    # Replay shuffled -- both should now be duplicates regardless of order.
    shuffled = df.iloc[::-1].reset_index(drop=True)
    results = processor.process_events(shuffled)
    assert all(r["status"] == "duplicate" for r in results)
