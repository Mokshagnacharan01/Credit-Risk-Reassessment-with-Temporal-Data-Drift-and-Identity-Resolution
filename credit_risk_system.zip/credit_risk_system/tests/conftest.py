"""
Shared pytest fixtures. Each test gets a fully isolated working directory
(models/, audit_logs/) so tests never interfere with each other or with
any state left over from manual CLI/API runs.
"""
import os
import shutil
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.event_processor import EventProcessor
from src import risk_model


@pytest.fixture
def isolated_state(tmp_path, monkeypatch):
    """Redirect all persisted state (models, audit logs, event log, history)
    into a fresh tmp_path for this test only."""
    models_dir = tmp_path / "models"
    audit_dir = tmp_path / "audit_logs"
    models_dir.mkdir()
    audit_dir.mkdir()

    monkeypatch.setattr(risk_model, "MODELS_DIR", str(models_dir))
    monkeypatch.setattr(risk_model, "STATE_PATH", str(models_dir / "risk_state.json"))

    from src import event_log as event_log_module
    monkeypatch.setattr(event_log_module, "LOG_DIR", str(audit_dir))
    monkeypatch.setattr(event_log_module, "LOG_PATH", str(audit_dir / "event_log.json"))

    from src import audit as audit_module
    monkeypatch.setattr(audit_module, "AUDIT_DIR", str(audit_dir))

    yield {"models_dir": str(models_dir), "audit_dir": str(audit_dir), "tmp_path": str(tmp_path)}


@pytest.fixture
def historical_df():
    np.random.seed(0)
    n = 200
    df = pd.DataFrame({
        "event_id": [f"H{i:04d}" for i in range(n)],
        "timestamp": pd.date_range("2025-01-01", periods=n, freq="6h"),
        "customer_id": [f"CUST{i%80:04d}" for i in range(n)],
        "account_id": [f"ACC{i%80:04d}" for i in range(n)],
        "payment_delay": np.random.exponential(3, n).round(1),
        "transaction_count": np.random.poisson(20, n),
        "credit_inquiry": np.random.poisson(1, n),
        "source": np.random.choice(["payment", "transaction", "credit_inquiry"], n),
    })
    risk_score = 0.15 * df.payment_delay + 0.6 * df.credit_inquiry - 0.05 * df.transaction_count
    prob = 1 / (1 + np.exp(-(risk_score - 2)))
    df["is_default"] = (np.random.rand(n) < prob).astype(int)
    return df


@pytest.fixture
def processor(isolated_state, historical_df):
    proc = EventProcessor.__new__(EventProcessor)
    proc.model_version = "v1"
    proc.model = None
    proc.train_initial_model(historical_df)
    proc.risk_state = risk_model.RiskState.load()

    from src.event_log import EventLog
    proc.event_log = EventLog()

    proc.history_path = os.path.join(isolated_state["audit_dir"], "full_history.csv")
    proc.history = proc._load_history()
    return proc
