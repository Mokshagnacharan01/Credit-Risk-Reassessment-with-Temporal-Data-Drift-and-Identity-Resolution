import json

import numpy as np
import pandas as pd

from src.drift_detection import _ks_statistic, detect_drift


def test_ks_statistic_is_zero_for_identical_distributions():
    a = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    assert _ks_statistic(a, a.copy()) == 0.0


def test_ks_statistic_is_high_for_very_different_distributions():
    a = np.array([1.0] * 20)
    b = np.array([100.0] * 20)
    assert _ks_statistic(a, b) == 1.0


def test_detect_drift_flags_sharp_shift_in_payment_delay():
    dates = pd.date_range("2025-04-01", periods=40, freq="D")
    payment_delay = list(np.round(np.random.RandomState(1).normal(2, 0.3, 25), 1)) + list(
        np.round(np.random.RandomState(2).normal(9, 0.5, 15), 1)
    )
    history = pd.DataFrame({
        "timestamp": dates,
        "payment_delay": payment_delay,
        "transaction_count": [20] * 25 + [6] * 15,
        "credit_inquiry": [0] * 25 + [3] * 15,
    })
    # Evaluate as_of a date well into the shifted period.
    results = detect_drift(history, as_of=dates[35])
    drifted_features = {r.feature for r in results if r.drifted}
    assert "payment_delay" in drifted_features


def test_detect_drift_no_drift_for_stable_distribution():
    dates = pd.date_range("2025-04-01", periods=40, freq="D")
    history = pd.DataFrame({
        "timestamp": dates,
        "payment_delay": np.round(np.random.RandomState(3).normal(2, 0.2, 40), 1),
        "transaction_count": np.random.RandomState(4).poisson(20, 40),
        "credit_inquiry": np.random.RandomState(5).poisson(1, 40),
    })
    results = detect_drift(history, as_of=dates[35])
    assert not any(r.drifted for r in results)


def test_drift_triggers_are_recorded_in_end_to_end_audit(processor):
    dates = pd.date_range("2025-04-01", periods=40, freq="D").astype(str)
    payment_delay = list(np.round(np.random.RandomState(1).normal(2, 0.3, 25), 1)) + list(
        np.round(np.random.RandomState(2).normal(9, 0.5, 15), 1)
    )
    rows = []
    for i in range(40):
        rows.append({
            "event_id": f"D{i:03d}",
            "timestamp": dates[i],
            "customer_id": "CUSTD1",
            "account_id": "ACCD1",
            "payment_delay": payment_delay[i],
            "transaction_count": 20 if i < 25 else 6,
            "credit_inquiry": 0 if i < 25 else 3,
            "source": "payment",
            "is_default": 0 if i < 25 else 1,
        })
    df = pd.DataFrame(rows)
    results = processor.process_events(df)
    drift_flags = []
    for r in results:
        with open(r["audit_file"]) as f:
            drift_flags.append(json.load(f)["drift_detected"])
    assert any(drift_flags), "Expected at least one event to trigger drift detection"
    assert not all(drift_flags), "Expected early (pre-shift) events to NOT show drift"
