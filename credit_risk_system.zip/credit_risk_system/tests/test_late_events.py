import json

import pandas as pd


def _event(event_id, ts, cust="CUST1", acc="ACC1", pd_=2.0, tc=10, ci=0, default=0):
    return {
        "event_id": event_id,
        "timestamp": ts,
        "customer_id": cust,
        "account_id": acc,
        "payment_delay": pd_,
        "transaction_count": tc,
        "credit_inquiry": ci,
        "source": "payment",
        "is_default": default,
    }


def test_late_event_is_flagged_and_updates_state(processor):
    # Two events "now", then a late one with an earlier timestamp arrives.
    df1 = pd.DataFrame([
        _event("E1", "2025-06-05 12:00:00"),
        _event("E2", "2025-06-06 12:00:00"),
    ])
    processor.process_events(df1)

    df2 = pd.DataFrame([_event("E3", "2025-06-04 08:00:00", pd_=8.0, tc=5, ci=2)])
    results = processor.process_events(df2)

    assert results[0]["status"] == "processed"
    with open(results[0]["audit_file"]) as f:
        audit = json.load(f)
    assert audit["late_event"] is True

    # State should reflect the late event as the most recent processed evidence.
    state = processor.risk_state.get("ACC1")
    assert state["last_event_id"] == "E3"


def test_non_late_event_is_not_flagged(processor):
    df = pd.DataFrame([
        _event("E1", "2025-06-05 12:00:00"),
        _event("E2", "2025-06-06 12:00:00"),
    ])
    results = processor.process_events(df)
    for r in results:
        with open(r["audit_file"]) as f:
            audit = json.load(f)
        assert audit["late_event"] is False
