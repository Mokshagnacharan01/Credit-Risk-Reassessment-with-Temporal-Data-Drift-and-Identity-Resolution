import pandas as pd

from src.identity_resolution import resolve_identities


def test_merges_on_matching_account_id_despite_different_customer_id():
    events = pd.DataFrame({
        "event_id": ["E1", "E2", "E3"],
        "customer_id": ["CUST1", "CUST1B", "CUSTX1"],
        "account_id": ["ACC1", "ACC1", "ACC1"],
        "transaction_count": [10, 11, 12],
    })
    result = resolve_identities(events)
    assert result["merged_customer_id"].nunique() == 1
    assert set(result["merged_customer_id"]) == {"ACC1"}


def test_does_not_merge_different_accounts_with_similar_customer_ids():
    events = pd.DataFrame({
        "event_id": ["E1", "E2"],
        "customer_id": ["CUST9002", "CUST9006"],
        "account_id": ["ACC9002", "ACC9006"],
        "transaction_count": [10, 11],
    })
    result = resolve_identities(events)
    assert result["merged_customer_id"].nunique() == 2


def test_fuzzy_matches_when_account_id_missing_on_both_sides():
    events = pd.DataFrame({
        "event_id": ["E1", "E2"],
        "customer_id": ["CUST9006", "CUST90O6"],  # typo: O vs 0
        "account_id": ["", ""],
        "transaction_count": [11, 12],
    })
    result = resolve_identities(events)
    assert result["merged_customer_id"].nunique() == 1


def test_fuzzy_match_does_not_cross_an_authoritative_account_id():
    """An event with no account_id must not fuzzy-merge into a customer
    whose events *do* carry an (different) account_id -- account_id is
    authoritative whenever it's present."""
    events = pd.DataFrame({
        "event_id": ["E1", "E2", "E3"],
        "customer_id": ["CUST9002", "CUST9002", "CUST9006"],
        "account_id": ["ACC9002", "ACC9002", ""],
        "transaction_count": [10, 11, 11],
    })
    result = resolve_identities(events)
    e3_cluster = result.loc[result.event_id == "E3", "merged_customer_id"].iloc[0]
    acc_cluster = result.loc[result.event_id == "E1", "merged_customer_id"].iloc[0]
    assert e3_cluster != acc_cluster


def test_missing_customer_id_does_not_crash_and_gets_own_cluster():
    events = pd.DataFrame({
        "event_id": ["E1", "E2"],
        "customer_id": [None, "CUST5"],
        "account_id": ["", ""],
        "transaction_count": [5, 50],
    })
    result = resolve_identities(events)
    assert len(result) == 2
    assert result["merged_customer_id"].notna().all()


def test_resolution_is_order_independent():
    events = pd.DataFrame({
        "event_id": ["E3", "E1", "E2"],
        "customer_id": ["CUSTX1", "CUST1", "CUST1B"],
        "account_id": ["ACC1", "ACC1", "ACC1"],
        "transaction_count": [12, 10, 11],
    })
    shuffled = events.sample(frac=1, random_state=1).reset_index(drop=True)
    r1 = resolve_identities(events)
    r2 = resolve_identities(shuffled)
    m1 = dict(zip(r1.event_id, r1.merged_customer_id))
    m2 = dict(zip(r2.event_id, r2.merged_customer_id))
    assert m1 == m2
