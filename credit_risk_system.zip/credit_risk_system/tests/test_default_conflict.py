import json

import pandas as pd

from src.event_processor import _resolve_is_default_conflict


def _event(event_id, ts, default, cust="CUST1", acc="ACC1"):
    return {
        "event_id": event_id,
        "timestamp": ts,
        "customer_id": cust,
        "account_id": acc,
        "payment_delay": 2.0,
        "transaction_count": 10,
        "credit_inquiry": 0,
        "source": "payment",
        "is_default": default,
    }


def test_no_conflict_when_labels_agree():
    df = pd.DataFrame([_event("E1", "2025-06-01", 0), _event("E2", "2025-06-02", 0)])
    result = _resolve_is_default_conflict(df)
    assert result == {}


def test_majority_vote_resolves_conflict():
    df = pd.DataFrame([
        _event("E1", "2025-06-01", 0),
        _event("E2", "2025-06-02", 1),
        _event("E3", "2025-06-03", 1),
    ])
    result = _resolve_is_default_conflict(df)
    assert result["conflict"] is True
    assert result["resolved_value"] == 1
    assert result["resolution_method"] == "majority_vote"


def test_tie_broken_by_most_recent_timestamp():
    df = pd.DataFrame([
        _event("E1", "2025-06-01", 0),
        _event("E2", "2025-06-03", 1),  # most recent, tied 1-1
    ])
    result = _resolve_is_default_conflict(df)
    assert result["conflict"] is True
    assert result["resolved_value"] == 1
    assert result["resolution_method"] == "majority_vote_tie_broken_by_most_recent_timestamp"


def test_end_to_end_conflict_is_recorded_in_audit(processor):
    df = pd.DataFrame([
        _event("E1", "2025-06-10 09:00:00", 0),
        _event("E2", "2025-06-10 09:05:00", 1),
        _event("E3", "2025-06-10 09:10:00", 1),
    ])
    results = processor.process_events(df)
    with open(results[-1]["audit_file"]) as f:
        audit = json.load(f)
    assert audit["is_default_conflict"] is not None
    assert audit["is_default_conflict"]["conflict"] is True
