# Real-Time Credit Risk Reassessment

A system that ingests time-stamped, asynchronous, and potentially conflicting
customer financial events, resolves customer identity across them, detects
temporal drift in feature distributions, and maintains a versioned,
auditable, idempotent risk score per customer.

## What's inside

| Module | Responsibility |
|---|---|
| `src/identity_resolution.py` | Deterministic identity resolution (account_id + fuzzy customer_id/transaction-history matching via Union-Find) |
| `src/drift_detection.py` | Rolling 30-day drift detection using a hand-rolled two-sample KS test (no SciPy, per constraints) + mean-shift check |
| `src/risk_model.py` | Logistic regression training/scoring, model versioning, persisted per-customer risk state |
| `src/event_log.py` | Idempotency ledger — tracks processed `event_id`s so replays never change state |
| `src/audit.py` | Writes a JSON audit trail for every decision (including skipped/duplicate ones) |
| `src/event_processor.py` | Orchestrates the pipeline end-to-end; the core `EventProcessor` class |
| `src/cli.py` | Command-line ingestion (`bootstrap`, `ingest`) |
| `src/api.py` | FastAPI server exposing `POST /events` |

## Clone → Setup → Run → Test

```bash
git clone <YOUR_REPO_URL>
cd credit_risk_system

python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt
```

### 1. Bootstrap the model

Train the initial logistic regression on historical labeled data (only
needs to be run once, or whenever you want to retrain):

```bash
python -m src.cli bootstrap --historical data/samples/historical_train.csv
```

This writes `models/model_v1.pkl`.

### 2. Ingest events via CLI

```bash
python -m src.cli ingest --file data/samples/edge_case_1_identity_conflict.csv
```

Each line of output is a JSON result per event: `{event_id, status,
merged_customer_id, score, audit_file}`, where `status` is `processed` or
`duplicate`.

### 3. Ingest events via the API

```bash
uvicorn src.api:app --reload
```

```bash
curl -X POST http://127.0.0.1:8000/events \
  -H "Content-Type: application/json" \
  -d '{
    "event_id": "E9001",
    "timestamp": "2025-06-01 09:00:00",
    "customer_id": "CUST1",
    "account_id": "ACC1",
    "payment_delay": 2.0,
    "transaction_count": 10,
    "credit_inquiry": 0,
    "source": "payment",
    "is_default": 0
  }'
```

Responses: `200` on success, `409` if the event was already processed
(replay), `400` if malformed.

### 4. Run the tests

```bash
pytest tests/ -v
```

All 20 tests should pass in well under a second.

### 5. Reset local state

The system persists everything as local files (no external DB, per
constraints). To start completely fresh:

```bash
rm -rf audit_logs/*.json audit_logs/full_history.csv models/*.pkl models/risk_state.json
```

## Design notes

**Identity resolution.** `account_id` is the authoritative signal — any two
events sharing one are merged. When it's missing, the system falls back to
fuzzy string matching on `customer_id` (via `difflib`, deterministic) plus
closeness of `transaction_count`, but **only** against other events that
also lack an `account_id` — otherwise a coincidentally-similar ID could
override an authoritative account match. Clustering uses Union-Find and is
processed in a stable, sorted order, so resolution is independent of the
order events arrive in.

**Drift detection.** Per the constraints, only NumPy/Pandas are allowed (no
SciPy), so the two-sample KS statistic is implemented from scratch using
empirical CDFs. Drift is flagged when KS > 0.3 or the feature mean shifts
by more than 15% between the customer's baseline history and their current
rolling 30-day window.

**Risk reassessment.** A logistic regression model (scikit-learn) is
trained once on historical labeled data and versioned (`model_v1.pkl`,
`model_v2.pkl`, ...). Any new event is treated as new evidence and triggers
a rescore; if drift is also detected, that's recorded in the audit trail as
the reason re-evaluation was warranted.

**Idempotency & replay.** A local JSON event log (`audit_logs/event_log.json`)
tracks every `event_id` that's been processed. Replaying an already-seen
event is a no-op for risk state — it's logged as a `duplicate` decision with
its own audit entry, but the score never changes.

**Late events.** An event whose timestamp is earlier than the customer's
most recently seen timestamp is still ingested and used to update state
(since it's new evidence), but is flagged `late_event: true` in its audit
record so downstream consumers know the update was retroactive.

**Conflicting `is_default` labels.** When a merged customer's history
contains disagreeing `is_default` values (e.g. from different sources),
the system resolves by majority vote, with ties broken by the most recent
timestamp. The conflict and its resolution are recorded in the audit
trail (`is_default_conflict` field) — nothing is silently dropped.

**Auditability.** Every decision (processed or duplicate) writes a JSON
file to `audit_logs/` with the input event id(s), identity resolution
reasoning, full drift detection results per feature, model version, final
score, and a human-readable `reasoning` list.

## Where things live

- **Sample event datasets (≥5 edge cases):** `data/samples/edge_case_*.csv`
  - `edge_case_1_identity_conflict.csv` — same account, mismatched customer_id
  - `edge_case_2_replay_duplicate.csv` — duplicate event_id (idempotency)
  - `edge_case_3_late_event.csv` — out-of-order/late timestamp
  - `edge_case_4_temporal_drift.csv` — sharp feature distribution shift
  - `edge_case_5_conflicting_default_labels.csv` — disagreeing is_default across sources
  - `edge_case_6_missing_id_fuzzy_match.csv` — missing account_id, typo'd customer_id
  - `edge_case_7_overlapping_windows.csv` — two customer_ids sharing one account in an interleaved window
  - `historical_train.csv` — bootstrap training data
  - `performance_test_1000_events.csv` — used for the performance benchmark below
- **Audit / decision-trace outputs:** `audit_logs/*.json` (one per decision), plus `audit_logs/event_log.json` (idempotency ledger) and `audit_logs/full_history.csv` (accumulated event history used for drift baselines)
- **Demo output (risk score evolution):** `demo/risk_score_evolution_ACC9004.png` — generated from `edge_case_4_temporal_drift.csv`, showing the score jump and drift flags exactly when the underlying distribution shifts
- **Trained model + state:** `models/model_v1.pkl`, `models/risk_state.json`
- **Tests:** `tests/test_identity_resolution.py`, `tests/test_replay.py`, `tests/test_late_events.py`, `tests/test_drift.py`, `tests/test_default_conflict.py`

## Performance

Processing 1000 events completes in well under the 5-second requirement:

```bash
python -m src.cli bootstrap --historical data/samples/historical_train.csv
python -m src.cli ingest --file data/samples/performance_test_1000_events.csv
```

## Constraints honored

- Pure Python + NumPy/Pandas/Matplotlib/scikit-learn only — no SciPy, no
  ML/LLM for identity resolution or drift detection.
- No external databases or cloud services — all state is local JSON/CSV/pickle.
- No distributed systems or microservices.
- CLI + FastAPI only (no other HTTP frameworks).
